const { Client, GatewayIntentBits } = require('discord.js');
const sqlite3 = require('sqlite3').verbose();
const express = require('express');

const token = 'OTczMzUxNjk5NzIyOTM2NDQw.GsSVuf.59aWZhhVfr9x7uADLiDingjk0hazs0Bdk0AVpc';  // Substitua pelo seu token
const guildId = '1101201933789839413';  // Substitua pelo ID do seu servidor

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildPresences,
  ],
});

// Configuração do banco de dados SQLite
const db = new sqlite3.Database('./botData.db', (err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err.message);
  } else {
    console.log('Conectado ao banco de dados SQLite.');
  }
});

// Criação de tabelas
db.run(`CREATE TABLE IF NOT EXISTS received_messages (user_id TEXT PRIMARY KEY)`);
db.run(`CREATE TABLE IF NOT EXISTS failed_messages (user_id TEXT PRIMARY KEY)`);

let sentCount = 0;

// Função para carregar IDs de mensagens já enviadas
async function loadReceivedMessageIds() {
  return new Promise((resolve, reject) => {
    db.all('SELECT user_id FROM received_messages', (err, rows) => {
      if (err) reject(err);
      resolve(new Set(rows.map(row => row.user_id)));
    });
  });
}

// Função para carregar IDs de mensagens falhas
async function loadFailedMessageIds() {
  return new Promise((resolve, reject) => {
    db.all('SELECT user_id FROM failed_messages', (err, rows) => {
      if (err) reject(err);
      resolve(new Set(rows.map(row => row.user_id)));
    });
  });
}

// Função para registrar IDs de mensagens falhas
function markAsFailed(userId) {
  return new Promise((resolve, reject) => {
    db.run('INSERT INTO failed_messages (user_id) VALUES (?)', [userId], (err) => {
      if (err) reject(err);
      resolve();
    });
  });
}

// Função para registrar IDs de mensagens enviadas
function markAsReceived(userId) {
  return new Promise((resolve, reject) => {
    db.run('INSERT INTO received_messages (user_id) VALUES (?)', [userId], (err) => {
      if (err) reject(err);
      resolve();
    });
  });
}

// Função para enviar mensagens com cooldown de 45ms
async function sendMessageToMember(member, receivedIds, failedIds, total) {
  try {
    if (member.user.bot || receivedIds.has(member.id) || failedIds.has(member.id)) return;

    await member.send('Oi, entra aqui tem uma surpresinha pra vc rs https://discord.gg/YhqHgB8txf');
    sentCount++;
    await markAsReceived(member.id);
    console.log(`✅ Mensagem enviada: ${member.user.username} (${sentCount}/${total})`);

    // Cooldown de 45ms entre os envios
    await new Promise(resolve => setTimeout(resolve, 45)); // 45 milissegundos
  } catch (error) {
    if (error.code === 50007) {
      // Código 50007: Não é possível enviar mensagens para o usuário
      await markAsFailed(member.id);
      console.log(`⚠️ Privado fechado: ${member.user.username}`);
    } else {
      console.log(`⚠️ Erro inesperado com ${member.user.username}: ${error.message}`);
    }
  }
}

// Função principal para enviar mensagens
async function sendMessagesAutomatically() {
  try {
    console.log('Carregando membros do servidor...');
    const guild = await client.guilds.fetch(guildId);
    const members = await guild.members.fetch();

    console.log('Carregando mensagens já enviadas e falhas...');
    const receivedIds = await loadReceivedMessageIds();
    const failedIds = await loadFailedMessageIds();

    // Prioriza membros por status
    const sortedMembers = [
      ...members.filter(member => member.presence?.status === 'online').values(),
      ...members.filter(member => member.presence?.status === 'idle').values(),
      ...members.filter(member => member.presence?.status === 'dnd').values(),
      ...members.filter(member => !member.presence || member.presence.status === 'offline').values(),
    ];

    const total = sortedMembers.length;

    console.log(`Iniciando envio de mensagens (${total} membros)...`);
    const promises = sortedMembers.map(member =>
      sendMessageToMember(member, receivedIds, failedIds, total)
    );

    // Espera todos os envios terminarem
    await Promise.all(promises);

    console.log(`\n✅ Relatório final:`);
    console.log(`✅ Mensagens enviadas com sucesso: ${sentCount}`);
    console.log(`✅ Mensagens com privado fechado ignoradas: ${failedIds.size}`);
  } catch (error) {
    console.error(`Erro no envio automático: ${error.message}`);
  }
}

// Evento quando o bot estiver pronto
client.once('ready', async () => {
  console.clear();
  console.log(`\n-----------------------------`);
  console.log(`        🌟 FLUXO 🌟         `);
  console.log(`-----------------------------\n`);
  console.log('Bot está online!');
  await sendMessagesAutomatically();
});

// Servidor Express para monitoramento
const app = express();
app.get('/', (req, res) => {
  res.send('Bot está online!');
});

app.listen(3000, () => {
  console.log('Servidor de ping rodando na porta 3000');
});

client.login(token);